module.exports = {
    // ...other configurations
    transform: {
        "^.+\\.(js|jsx)$": "babel-jest",
    },
};
