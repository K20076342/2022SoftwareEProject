import React from "react";
import Overview from "../../pages/Overview/Overview";
import './ProfileLayout.css'



const ProfileLayout = () => {


  return (
    <div>


      <div className="content">
        <Overview />
      </div>


    </div>
  );

}


export default ProfileLayout;